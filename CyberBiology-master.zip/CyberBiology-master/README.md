## About

CyberBiology - life simulator on computer

## Build

### Linux

Build artifact:
```bash
make
```

You can run after build:
```build
java ./build/world.jar
```
